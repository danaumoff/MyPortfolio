window.onload = function() {
    let btn_quit = document.getElementById("btn-quit");
    btn_quit.onclick = function() {
        window.location.href = "/quit.php";
    }
}
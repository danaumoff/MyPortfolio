<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PROgamer - лучшие PC</title>
    <link rel='stylesheet' href='/styles/main.css'>
</head>

<body>
    <script src="/js/bg.js"></script>
    <header>
        <h1>Хей, хочешь новый PC тогда тебе к нам!</h1>
        <h1>Залетай!</h1>
    </header>
    <section>
        <?php
        if (!$_SESSION['logged_in']) {
            ?>
            <div>
                <a href="register/"><input type="button" value="Регистрация" id="reg"></a>
            </div>
            <div>
                <a href="auth/"><input type="button" value="Вход" id="enter"></a>
            </div>
            <?php
        } else {
        ?>
            <div>
                <a href="menu/"><input type="button" value="В меню" id="enter"></a>
            </div>
        <?php
        }
        ?>
       
    </section>
</body>

</html>
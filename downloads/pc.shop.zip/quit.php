<?php 
session_start();
$_SESSION["logged_in"] = false;
$_SESSION["name"] = '';
echo "<meta http-equiv='refresh' content='0; /'>";
from main import add_gpus_to_db
add_gpus_to_db()